Please download 'GeoLiteCity' package from
http://geolite.maxmind.com/download/geoip/database/GeoLiteCity.dat.gz
and gunzip in this directory.

The GeoLite databases are distributed under the Creative Commons
Attribution-ShareAlike 3.0 Unported License.

For more Informations, visit: http://dev.maxmind.com/geoip/legacy/geolite/