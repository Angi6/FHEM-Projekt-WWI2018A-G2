/* iOS 12 Theme for FHEM */
/* by Sandra Ohmayer */
/* http://www.foodcat.de */
/* jQuery is required*/

var imported = document.createElement('script');
imported.src = '/fhem/pgm2/ios12touchpad.js';
document.head.appendChild(imported);
