/* iOS 6 Theme for FHEM */
/* by Sandra Ohmayer */
/* http://www.foodcat.de */
/* jQuery is required*/

var imported = document.createElement('script');
imported.src = '/fhem/pgm2/ios6touchpad.js';
document.head.appendChild(imported);
