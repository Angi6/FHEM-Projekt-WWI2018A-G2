This is the readme of the new Webfrontend, based on ExtJS.
As there is no full documentation available at the moment, 
please refer to this thread on the forums of FHEM to get help, ask questions or get updates:

http://forum.fhem.de/index.php?t=msg&th=10439&start=0&rid=0

The ExtJS Library as well as the application itself are available under the GPLv3 License - http://www.sencha.com/

See the license.txt in the lib folder for details
